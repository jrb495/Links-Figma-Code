import React, { useState, useEffect } from "react";
import { GolfCourseProvider } from "./components/GolfCourseContext";
import { AddCourseForm } from "./components/AddCourseForm";
import { CourseComparison } from "./components/CourseComparison";
import { RankingsList } from "./components/RankingsList";
import { Navigation } from "./components/Navigation";
import { SearchCourses } from "./components/SearchCourses";
import { GolferAnimation } from "./components/GolferAnimation";
import { LinksLogoNew } from "./components/LinksLogoNew";
import { BulkImportForm } from "./components/BulkImportForm";
import { InitialRatings } from "./components/InitialRatings";
import { ProfileForm } from "./components/ProfileForm";
import { useGolfCourses } from "./components/GolfCourseContext";

// Component to determine if we should show initial ratings or regular content
const AppContent: React.FC = () => {
  const { getPlayedCoursesCount, isProfileComplete } = useGolfCourses();
  const [activeView, setActiveView] = useState("initial");
  const [hasRatedCourses, setHasRatedCourses] = useState(false);
  
  // Check if user has any rated courses
  useEffect(() => {
    setHasRatedCourses(getPlayedCoursesCount() > 0);
  }, [getPlayedCoursesCount]);

  // Check if there's a view in the URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const view = params.get('view');
    
    // If user hasn't rated courses yet, show initial ratings unless explicitly navigating elsewhere
    if (!hasRatedCourses && !view) {
      setActiveView("initial");
    }
    // Otherwise respect URL param or default to search
    else if (view) {
      // Fix for "rank" URL parameter - redirect to "compare" view
      if (view === "rank") {
        setActiveView("compare");
        // Update URL to the correct parameter without reloading
        window.history.replaceState({}, "", "/?view=compare");
      }
      // Normal handling for valid views
      else if (['add', 'search', 'compare', 'rankings', 'bulk', 'initial', 'profile'].includes(view)) {
        setActiveView(view);
      } else {
        setActiveView("search");
      }
    } else {
      setActiveView("search");
    }
  }, [hasRatedCourses]);

  // Update URL when view changes
  const handleViewChange = (view: string) => {
    setActiveView(view);
    window.history.pushState({}, "", `?view=${view}`);
  };

  const renderActiveView = () => {
    switch (activeView) {
      case "initial":
        return <InitialRatings onComplete={handleViewChange} />;
      case "add":
        return <AddCourseForm />;
      case "search":
        return <SearchCourses />;
      case "compare":
        return <CourseComparison />;
      case "rankings":
        return <RankingsList />;
      case "bulk":
        return <BulkImportForm />;
      case "profile":
        return <ProfileForm />;
      default:
        return hasRatedCourses ? <SearchCourses /> : <InitialRatings onComplete={handleViewChange} />;
    }
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 bg-[url('https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3')] bg-fixed bg-cover bg-center bg-opacity-20 bg-blend-overlay">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8 bg-card/90 p-6 rounded-lg shadow-md border border-primary/20">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
            <LinksLogoNew className="h-20 w-auto" showTagline={true} />
          </div>
          
          {/* Golf Animation */}
          <div className="mt-4 border-t border-primary/20 pt-4">
            <GolferAnimation />
          </div>
        </header>
        
        <Navigation activeView={activeView} setActiveView={handleViewChange} />
        
        <main className="mt-6 bg-card/90 p-6 rounded-lg shadow-md border border-primary/20">
          {renderActiveView()}
        </main>
        
        <footer className="mt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Links. All rights reserved.</p>
        </footer>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <GolfCourseProvider>
      <AppContent />
    </GolfCourseProvider>
  );
}