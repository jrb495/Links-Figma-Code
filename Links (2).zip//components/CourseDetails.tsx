import React, { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { GolfCourse, PlayingRound } from "./types";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useGolfCourses } from "./GolfCourseContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { CourseRatingBadge } from "./CourseRatingBadge";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger, 
  DialogFooter,
  DialogDescription
} from "./ui/dialog";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Label } from "./ui/label";

interface CourseDetailsProps {
  course: GolfCourse;
  onBack: () => void;
}

export const CourseDetails: React.FC<CourseDetailsProps> = ({ course, onBack }) => {
  const { updateCourse } = useGolfCourses();
  const [activeTab, setActiveTab] = useState("overview");
  const [notes, setNotes] = useState(course.notes || "");
  const [newRound, setNewRound] = useState<{
    date: string;
    score: string;
    partners: string;
    notes: string;
  }>({
    date: new Date().toISOString().split("T")[0],
    score: "",
    partners: "",
    notes: ""
  });

  // Placeholder for when we'd fetch user rounds data
  const userRounds: PlayingRound[] = course.roundsPlayed ? [
    {
      courseId: course.id,
      date: new Date("2025-04-15"),
      score: course.bestScore || 78,
      partners: ["John Smith", "Mike Johnson"]
    },
    {
      courseId: course.id,
      date: new Date("2025-03-22"),
      score: (course.bestScore || 78) + 5,
      partners: ["Sarah Williams"]
    }
  ] : [];

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleAddNotes = () => {
    updateCourse(course.id, { notes });
  };

  const handleAddRound = () => {
    // Validate data
    if (!newRound.score || !newRound.date) return;

    const score = parseInt(newRound.score);
    if (isNaN(score)) return;

    // Create new round object
    const round: PlayingRound = {
      courseId: course.id,
      date: new Date(newRound.date),
      score,
      partners: newRound.partners.split(",").map(p => p.trim()).filter(p => p),
      notes: newRound.notes
    };

    // Calculate new best score
    const bestScore = course.bestScore ? Math.min(course.bestScore, score) : score;
    
    // Update course with new round data
    updateCourse(course.id, {
      roundsPlayed: (course.roundsPlayed || 0) + 1,
      bestScore
    });

    // Reset form
    setNewRound({
      date: new Date().toISOString().split("T")[0],
      score: "",
      partners: "",
      notes: ""
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={onBack}
          className="border-primary/30 text-primary"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
            <path d="m12 19-7-7 7-7"></path>
            <path d="M19 12H5"></path>
          </svg>
          Back to My Courses
        </Button>

        <Dialog>
          <DialogTrigger asChild>
            <Button
              type="button"
              variant="outline"
              className="border-primary/30 text-primary"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
              Edit Details
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="text-primary">Edit Course Details</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <p className="text-muted-foreground">Edit course details functionality would go here.</p>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="overflow-hidden border border-secondary/30 bg-card">
        <div className="h-48 md:h-64 relative">
          <ImageWithFallback
            src={course.imageUrl}
            alt={course.name}
            className="object-cover w-full h-full"
          />
          {course.rating && (
            <div className="absolute top-4 right-4 scale-125">
              <CourseRatingBadge rating={course.rating} />
            </div>
          )}
          {course.rank && (
            <div className="absolute top-4 left-4 bg-primary text-primary-foreground font-bold text-lg w-10 h-10 rounded-full flex items-center justify-center">
              #{course.rank}
            </div>
          )}
        </div>

        <div className="p-5">
          <h1 className="text-primary mb-1">{course.name}</h1>
          <div className="flex items-center gap-2 text-secondary-foreground">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"></path>
              <circle cx="12" cy="10" r="3"></circle>
            </svg>
            <p>{course.location}</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="rounds">My Rounds</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Course Style</h3>
                  <p className="text-secondary-foreground">{course.courseStyle || "Links"}</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Course Par</h3>
                  <p className="text-secondary-foreground">{course.par || 72}</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Difficulty</h3>
                  <p className="text-secondary-foreground">{course.difficulty ? `${course.difficulty}/10` : "Not rated"}</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Rounds Played</h3>
                  <p className="text-secondary-foreground">{course.roundsPlayed || 0}</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Best Score</h3>
                  <p className="text-secondary-foreground">{course.bestScore || "N/A"}</p>
                </div>
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Added On</h3>
                  <p className="text-secondary-foreground">{formatDate(course.dateAdded)}</p>
                </div>
              </div>
              
              {course.designer && (
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Course Designer</h3>
                  <p className="text-secondary-foreground">{course.designer}</p>
                </div>
              )}
              
              {course.yearBuilt && (
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <h3 className="text-primary mb-1">Year Built</h3>
                  <p className="text-secondary-foreground">{course.yearBuilt}</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="rounds" className="space-y-4">
              {userRounds.length > 0 ? (
                <div className="space-y-3">
                  {userRounds.map((round, index) => (
                    <div key={index} className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                      <div className="flex justify-between">
                        <h3 className="text-primary">{formatDate(round.date)}</h3>
                        <p className="text-lg font-semibold text-primary">{round.score}</p>
                      </div>
                      <p className="text-secondary-foreground mt-1">
                        Played with: {round.partners.join(", ")}
                      </p>
                      {round.notes && <p className="text-muted-foreground mt-2">{round.notes}</p>}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center p-6">
                  <p className="text-secondary-foreground mb-4">You haven't recorded any rounds at this course yet.</p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline"
                        className="border-primary text-primary"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                          <path d="M12 5v14"></path>
                          <path d="M5 12h14"></path>
                        </svg>
                        Add Round
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add New Round</DialogTitle>
                        <DialogDescription>
                          Record details about your round at {course.name}.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="date" className="text-right">
                            Date
                          </Label>
                          <Input
                            id="date"
                            type="date"
                            value={newRound.date}
                            onChange={(e) => setNewRound({...newRound, date: e.target.value})}
                            className="col-span-3"
                          />
                        </div>
                        
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="score" className="text-right">
                            Score
                          </Label>
                          <Input
                            id="score"
                            type="number"
                            value={newRound.score}
                            onChange={(e) => setNewRound({...newRound, score: e.target.value})}
                            className="col-span-3"
                            placeholder="Your total score"
                          />
                        </div>
                        
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="partners" className="text-right">
                            Playing Partners
                          </Label>
                          <Input
                            id="partners"
                            value={newRound.partners}
                            onChange={(e) => setNewRound({...newRound, partners: e.target.value})}
                            className="col-span-3"
                            placeholder="Names, comma separated"
                          />
                        </div>
                        
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="notes" className="text-right">
                            Notes
                          </Label>
                          <Textarea
                            id="notes"
                            value={newRound.notes}
                            onChange={(e) => setNewRound({...newRound, notes: e.target.value})}
                            className="col-span-3"
                            placeholder="Any memorable moments from your round"
                          />
                        </div>
                      </div>
                      
                      <DialogFooter>
                        <Button type="submit" onClick={handleAddRound}>
                          Save Round
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              )}
              
              {userRounds.length > 0 && (
                <div className="flex justify-center mt-4">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline"
                        className="border-primary text-primary"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                          <path d="M12 5v14"></path>
                          <path d="M5 12h14"></path>
                        </svg>
                        Add Another Round
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add New Round</DialogTitle>
                        <DialogDescription>
                          Record details about your round at {course.name}.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="date" className="text-right">
                            Date
                          </Label>
                          <Input
                            id="date"
                            type="date"
                            value={newRound.date}
                            onChange={(e) => setNewRound({...newRound, date: e.target.value})}
                            className="col-span-3"
                          />
                        </div>
                        
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="score" className="text-right">
                            Score
                          </Label>
                          <Input
                            id="score"
                            type="number"
                            value={newRound.score}
                            onChange={(e) => setNewRound({...newRound, score: e.target.value})}
                            className="col-span-3"
                            placeholder="Your total score"
                          />
                        </div>
                        
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="partners" className="text-right">
                            Playing Partners
                          </Label>
                          <Input
                            id="partners"
                            value={newRound.partners}
                            onChange={(e) => setNewRound({...newRound, partners: e.target.value})}
                            className="col-span-3"
                            placeholder="Names, comma separated"
                          />
                        </div>
                        
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="notes" className="text-right">
                            Notes
                          </Label>
                          <Textarea
                            id="notes"
                            value={newRound.notes}
                            onChange={(e) => setNewRound({...newRound, notes: e.target.value})}
                            className="col-span-3"
                            placeholder="Any memorable moments from your round"
                          />
                        </div>
                      </div>
                      
                      <DialogFooter>
                        <Button type="submit" onClick={handleAddRound}>
                          Save Round
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="notes">
              {course.notes ? (
                <div className="p-4 rounded-lg bg-accent/30 border border-primary/10">
                  <p className="text-secondary-foreground whitespace-pre-line">{course.notes}</p>
                  
                  <div className="flex justify-end mt-4">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline"
                          size="sm"
                          className="border-primary/30 text-primary"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                          </svg>
                          Edit Notes
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Course Notes</DialogTitle>
                          <DialogDescription>
                            Edit your personal notes about {course.name}.
                          </DialogDescription>
                        </DialogHeader>
                        
                        <div className="py-4">
                          <Textarea
                            value={notes}
                            onChange={(e) => setNotes(e.target.value)}
                            className="min-h-[200px]"
                            placeholder="Write your notes about this course..."
                          />
                        </div>
                        
                        <DialogFooter>
                          <Button type="submit" onClick={handleAddNotes}>
                            Save Notes
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              ) : (
                <div className="text-center p-6">
                  <p className="text-secondary-foreground mb-4">You haven't added any notes for this course.</p>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        variant="outline"
                        className="border-primary text-primary"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                          <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                          <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                        </svg>
                        Add Notes
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Course Notes</DialogTitle>
                        <DialogDescription>
                          Add your personal notes about {course.name}.
                        </DialogDescription>
                      </DialogHeader>
                      
                      <div className="py-4">
                        <Textarea
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          className="min-h-[200px]"
                          placeholder="Write your notes about this course..."
                        />
                      </div>
                      
                      <DialogFooter>
                        <Button type="submit" onClick={handleAddNotes}>
                          Save Notes
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </Card>
    </div>
  );
};