import React, { createContext, useContext, useState, useEffect } from "react";
import { GolfCourse, ComparisonResult, CourseDatabase, CourseRatingEvent, UserProfile } from "./types";

// Sample golf course database
const golfCourseDatabase: CourseDatabase[] = [
  {
    id: "augusta-national",
    name: "Augusta National Golf Club",
    location: "Augusta, Georgia",
    imageUrl: "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Parkland",
    par: 72,
    yearBuilt: 1933,
    designer: "Alister MacKenzie, Bobby Jones"
  },
  {
    id: "pebble-beach",
    name: "Pebble Beach Golf Links",
    location: "Pebble Beach, California",
    imageUrl: "https://images.unsplash.com/photo-1535131749006-b7d58e929de3?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 72,
    yearBuilt: 1919,
    designer: "Jack Neville, Douglas Grant"
  },
  {
    id: "st-andrews",
    name: "St Andrews Links (Old Course)",
    location: "St Andrews, Scotland",
    imageUrl: "https://images.unsplash.com/photo-1584210867758-9a855a8fe0c7?q=80&w=1974&auto=format&fit=crop",
    courseStyle: "Links",
    par: 72,
    yearBuilt: 1552,
    designer: "Old Tom Morris"
  },
  {
    id: "pinehurst-no2",
    name: "Pinehurst No. 2",
    location: "Pinehurst, North Carolina",
    imageUrl: "https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Sandhills",
    par: 72,
    yearBuilt: 1907,
    designer: "Donald Ross"
  },
  {
    id: "royal-county-down",
    name: "Royal County Down Golf Club",
    location: "Newcastle, Northern Ireland",
    imageUrl: "https://images.unsplash.com/photo-1535132011086-b8818f016104?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 71,
    yearBuilt: 1889,
    designer: "Old Tom Morris"
  },
  {
    id: "shinnecock-hills",
    name: "Shinnecock Hills Golf Club",
    location: "Southampton, New York",
    imageUrl: "https://images.unsplash.com/photo-1611374243147-44a702c2e414?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 70,
    yearBuilt: 1891,
    designer: "William Flynn"
  },
  {
    id: "oakmont",
    name: "Oakmont Country Club",
    location: "Oakmont, Pennsylvania",
    imageUrl: "https://images.unsplash.com/photo-1562128755-08c1f30b6ddb?q=80&w=1974&auto=format&fit=crop",
    courseStyle: "Parkland",
    par: 71,
    yearBuilt: 1903,
    designer: "Henry Fownes"
  },
  {
    id: "muirfield",
    name: "Muirfield",
    location: "Gullane, Scotland",
    imageUrl: "https://images.unsplash.com/photo-1535131749006-b7d58e929de3?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 71,
    yearBuilt: 1744,
    designer: "Old Tom Morris"
  },
  {
    id: "tpc-sawgrass",
    name: "TPC Sawgrass (Players Stadium)",
    location: "Ponte Vedra Beach, Florida",
    imageUrl: "https://images.unsplash.com/photo-1600720736771-55d418a2d7f7?q=80&w=1935&auto=format&fit=crop",
    courseStyle: "Stadium",
    par: 72,
    yearBuilt: 1980,
    designer: "Pete Dye"
  },
  {
    id: "cypress-point",
    name: "Cypress Point Club",
    location: "Pebble Beach, California",
    imageUrl: "https://images.unsplash.com/photo-1589395937772-7c0fbfea9233?q=80&w=1974&auto=format&fit=crop",
    courseStyle: "Links",
    par: 72,
    yearBuilt: 1928,
    designer: "Alister MacKenzie"
  },
  {
    id: "royal-melbourne",
    name: "Royal Melbourne Golf Club",
    location: "Black Rock, Victoria, Australia",
    imageUrl: "https://images.unsplash.com/photo-1564524497843-5871dcdaa66c?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Sandbelt",
    par: 72,
    yearBuilt: 1891,
    designer: "Alister MacKenzie"
  },
  {
    id: "bethpage-black",
    name: "Bethpage Black Course",
    location: "Farmingdale, New York",
    imageUrl: "https://images.unsplash.com/photo-1465187233517-9559238d2142?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Parkland",
    par: 71,
    yearBuilt: 1936,
    designer: "A.W. Tillinghast"
  },
  {
    id: "kiawah-ocean",
    name: "Kiawah Island (Ocean Course)",
    location: "Kiawah Island, South Carolina",
    imageUrl: "https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 72,
    yearBuilt: 1991,
    designer: "Pete Dye"
  },
  {
    id: "bandon-dunes",
    name: "Bandon Dunes Golf Resort",
    location: "Bandon, Oregon",
    imageUrl: "https://images.unsplash.com/photo-1535132011086-b8818f016104?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 72,
    yearBuilt: 1999,
    designer: "David McLay Kidd"
  },
  {
    id: "whistling-straits",
    name: "Whistling Straits (Straits Course)",
    location: "Sheboygan, Wisconsin",
    imageUrl: "https://images.unsplash.com/photo-1611374243147-44a702c2e414?q=80&w=2070&auto=format&fit=crop",
    courseStyle: "Links",
    par: 72,
    yearBuilt: 1998,
    designer: "Pete Dye"
  },
  // Add more courses to the database...
];

interface GolfCourseContextProps {
  courses: GolfCourse[];
  addCourse: (course: Omit<GolfCourse, "id" | "dateAdded" | "comparisonCount">) => GolfCourse;
  addCourseFromDatabase: (courseId: string) => GolfCourse | null;
  updateCourse: (courseId: string, updates: Partial<GolfCourse>) => void;
  deleteCourse: (courseId: string) => void;
  searchCourses: (query: string, options?: {diversify?: boolean}) => CourseDatabase[];
  getPlayedCoursesCount: () => number;
  getUnplayedCoursesCount: () => number;
  getAllCourses: () => GolfCourse[];
  getPlayedCourses: () => GolfCourse[];
  getUnplayedCourses: () => GolfCourse[];
  getRankedCourses: () => GolfCourse[];
  getCourseById: (id: string) => GolfCourse | undefined;
  recordComparison: (winnerId: string, loserId: string) => void;
  getRandomCourseForComparison: (excludeId?: string, similarRank?: boolean) => GolfCourse | null;
  champion: string | null;
  setChampion: (courseId: string | null) => void;
  championComparisonCount: number;
  allCourses: CourseDatabase[];
  importCourses: (coursesToImport: CourseDatabase[]) => void;
  getRecentSearches: () => string[];
  saveRecentSearch: (searchTerm: string) => void;
  setCourseRating: (courseId: string, rating: number) => void;
  // User profile management
  userProfile: UserProfile | null;
  saveUserProfile: (profile: UserProfile) => void;
  isProfileComplete: () => boolean;
}

const GolfCourseContext = createContext<GolfCourseContextProps | undefined>(undefined);

export const GolfCourseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [courses, setCourses] = useState<GolfCourse[]>([]);
  const [comparisons, setComparisons] = useState<ComparisonResult[]>([]);
  const [champion, setChampion] = useState<string | null>(null);
  const [championComparisonCount, setChampionComparisonCount] = useState(0);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [importedCourses, setImportedCourses] = useState<CourseDatabase[]>([]);
  const [courseRatings, setCourseRatings] = useState<CourseRatingEvent[]>([]);
  // User profile state
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  // Load data from localStorage on initial load
  useEffect(() => {
    const savedCourses = localStorage.getItem("golfCourses");
    const savedComparisons = localStorage.getItem("courseComparisons");
    const savedChampion = localStorage.getItem("currentChampion");
    const savedChampionCount = localStorage.getItem("championComparisonCount");
    const savedSearches = localStorage.getItem("recentSearches");
    const savedImportedCourses = localStorage.getItem("importedCourses");
    const savedRatings = localStorage.getItem("courseRatings");
    const savedUserProfile = localStorage.getItem("userProfile");

    if (savedCourses) setCourses(JSON.parse(savedCourses));
    if (savedComparisons) setComparisons(JSON.parse(savedComparisons));
    if (savedChampion) setChampion(savedChampion);
    if (savedChampionCount) setChampionComparisonCount(parseInt(savedChampionCount, 10));
    if (savedSearches) setRecentSearches(JSON.parse(savedSearches));
    if (savedImportedCourses) setImportedCourses(JSON.parse(savedImportedCourses));
    if (savedRatings) setCourseRatings(JSON.parse(savedRatings));
    if (savedUserProfile) setUserProfile(JSON.parse(savedUserProfile));
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("golfCourses", JSON.stringify(courses));
  }, [courses]);

  useEffect(() => {
    localStorage.setItem("courseComparisons", JSON.stringify(comparisons));
  }, [comparisons]);

  useEffect(() => {
    if (champion) localStorage.setItem("currentChampion", champion);
    else localStorage.removeItem("currentChampion");
  }, [champion]);

  useEffect(() => {
    localStorage.setItem("championComparisonCount", championComparisonCount.toString());
  }, [championComparisonCount]);
  
  useEffect(() => {
    localStorage.setItem("recentSearches", JSON.stringify(recentSearches));
  }, [recentSearches]);
  
  useEffect(() => {
    localStorage.setItem("importedCourses", JSON.stringify(importedCourses));
  }, [importedCourses]);
  
  useEffect(() => {
    localStorage.setItem("courseRatings", JSON.stringify(courseRatings));
  }, [courseRatings]);
  
  useEffect(() => {
    if (userProfile) {
      localStorage.setItem("userProfile", JSON.stringify(userProfile));
    }
  }, [userProfile]);

  // Add a new golf course
  const addCourse = (course: Omit<GolfCourse, "id" | "dateAdded" | "comparisonCount">) => {
    const newCourse: GolfCourse = {
      ...course,
      id: `custom-${Date.now()}`,
      dateAdded: new Date(),
      comparisonCount: 0,
      // Initialize with a base ELO score of 1500
      eloScore: 1500,
    };

    setCourses((prevCourses) => [...prevCourses, newCourse]);
    return newCourse;
  };

  // Add a course from the database
  const addCourseFromDatabase = (courseId: string) => {
    // Check if course already exists
    const existingCourse = courses.find((c) => c.id === courseId);
    if (existingCourse) return existingCourse;

    // Find in database
    const allCoursesDb = [...golfCourseDatabase, ...importedCourses];
    const courseData = allCoursesDb.find((c) => c.id === courseId);
    if (!courseData) return null;

    const newCourse: GolfCourse = {
      id: courseData.id,
      name: courseData.name,
      location: courseData.location,
      imageUrl: courseData.imageUrl || "",
      notes: "",
      dateAdded: new Date(),
      played: false,
      comparisonCount: 0,
      courseStyle: courseData.courseStyle,
      par: courseData.par,
      yearBuilt: courseData.yearBuilt,
      designer: courseData.designer,
      // Initialize with a base ELO score of 1500
      eloScore: 1500,
    };

    setCourses((prevCourses) => [...prevCourses, newCourse]);
    return newCourse;
  };

  // Update an existing course
  const updateCourse = (courseId: string, updates: Partial<GolfCourse>) => {
    setCourses((prevCourses) =>
      prevCourses.map((course) =>
        course.id === courseId ? { ...course, ...updates } : course
      )
    );
  };

  // Delete a course
  const deleteCourse = (courseId: string) => {
    setCourses((prevCourses) => prevCourses.filter((course) => course.id !== courseId));
    
    // If this was the champion, clear champion
    if (champion === courseId) {
      setChampion(null);
      setChampionComparisonCount(0);
    }
  };

  // Search the course database
  const searchCourses = (query: string, options: {diversify?: boolean} = {}) => {
    if (!query.trim()) return [];
  
    const allCoursesDb = [...golfCourseDatabase, ...importedCourses];
    const lowerQuery = query.toLowerCase();

    // Score each result for relevance
    const scoredResults = allCoursesDb.map(course => {
      let score = 0;
      
      // Name match (highest priority)
      if (course.name.toLowerCase() === lowerQuery) {
        score += 100;
      } else if (course.name.toLowerCase().includes(lowerQuery)) {
        score += 50;
      }
      
      // Location match
      if (course.location.toLowerCase().includes(lowerQuery)) {
        score += 30;
      }
      
      // Course style match (e.g., "links")
      if (course.courseStyle?.toLowerCase().includes(lowerQuery)) {
        score += 20;
      }
      
      // Designer match
      if (course.designer?.toLowerCase().includes(lowerQuery)) {
        score += 15;
      }
      
      // Keyword match (if we have them)
      if (course.keywords?.some(keyword => keyword.toLowerCase().includes(lowerQuery))) {
        score += 25;
      }
      
      return { course, score };
    });
    
    // Filter out zero-score results and sort by relevance
    const filteredResults = scoredResults
      .filter(result => result.score > 0)
      .sort((a, b) => b.score - a.score);
      
    if (options.diversify && filteredResults.length > 5) {
      // Add some diversity in results by mixing in lower-scored results
      // This prevents the same few courses from always showing up
      const topResults = filteredResults.slice(0, Math.min(5, filteredResults.length));
      const remainingResults = filteredResults.slice(Math.min(5, filteredResults.length));
      
      // Randomly select some lower-scored results
      const randomSelection = remainingResults
        .sort(() => 0.5 - Math.random())
        .slice(0, Math.min(5, remainingResults.length));
      
      // Combine and shuffle a bit to prevent always the same order
      return [...topResults, ...randomSelection]
        .sort((a, b) => {
          // Keep general ordering by score but add some randomness
          const scoreDiff = b.score - a.score;
          if (scoreDiff > 30) return 1;  // Much better score stays on top
          if (Math.random() > 0.7) return -1;  // 30% chance of swapping
          return scoreDiff;
        })
        .map(result => result.course);
    }
      
    return filteredResults.map(result => result.course);
  };

  // Get all courses
  const getAllCourses = () => courses;

  // Get played courses
  const getPlayedCourses = () => courses.filter((course) => course.played);
  
  // Get played courses count
  const getPlayedCoursesCount = () => courses.filter((course) => course.played).length;
  
  // Get unplayed courses count
  const getUnplayedCoursesCount = () => courses.filter((course) => !course.played).length;

  // Get unplayed courses
  const getUnplayedCourses = () => courses.filter((course) => !course.played);

  // Get ranked courses
  const getRankedCourses = () => {
    const playedCourses = getPlayedCourses();
    
    // Calculate ranks based on ELO scores
    const sortedCourses = [...playedCourses].sort((a, b) => {
      return (b.eloScore || 1500) - (a.eloScore || 1500);
    });
    
    // Assign ranks
    return sortedCourses.map((course, index) => {
      return {
        ...course,
        rank: index + 1
      };
    });
  };

  // Get a course by ID
  const getCourseById = (id: string) => courses.find((course) => course.id === id);

  // Record a comparison result between two courses
  const recordComparison = (winnerId: string, loserId: string) => {
    const comparison: ComparisonResult = {
      winnerId,
      loserId,
      timestamp: new Date(),
    };

    setComparisons((prevComparisons) => [...prevComparisons, comparison]);

    // Update ELO scores
    const winner = getCourseById(winnerId);
    const loser = getCourseById(loserId);

    if (winner && loser) {
      // ELO calculation
      const winnerElo = winner.eloScore || 1500;
      const loserElo = loser.eloScore || 1500;
      
      // Calculate expected scores
      const expectedWinner = 1 / (1 + Math.pow(10, (loserElo - winnerElo) / 400));
      const expectedLoser = 1 / (1 + Math.pow(10, (winnerElo - loserElo) / 400));
      
      // K-factor (importance of the match)
      const kFactor = 32;
      
      // New ELO scores
      const newWinnerElo = Math.round(winnerElo + kFactor * (1 - expectedWinner));
      const newLoserElo = Math.round(loserElo + kFactor * (0 - expectedLoser));
      
      // Update courses
      updateCourse(winnerId, { 
        eloScore: newWinnerElo,
        comparisonCount: (winner.comparisonCount || 0) + 1,
        // Mark as played after 5 comparisons
        played: (winner.comparisonCount || 0) + 1 >= 5 ? true : winner.played
      });
      
      updateCourse(loserId, { 
        eloScore: newLoserElo,
        comparisonCount: (loser.comparisonCount || 0) + 1,
        // Mark as played after 5 comparisons
        played: (loser.comparisonCount || 0) + 1 >= 5 ? true : loser.played
      });
    }

    // If this is the champion, increment the comparison count
    if (winnerId === champion) {
      setChampionComparisonCount(prev => prev + 1);
    }
  };

  // Get a random course for comparison
  const getRandomCourseForComparison = (excludeId?: string, similarRank: boolean = true) => {
    // Get available courses, excluding the provided ID
    let availableCourses = courses.filter(c => c.id !== excludeId);
    
    if (availableCourses.length === 0) return null;
    
    // If we want similar rank and we have the exclude course
    if (similarRank && excludeId) {
      const excludeCourse = getCourseById(excludeId);
      
      if (excludeCourse && excludeCourse.eloScore) {
        // Sort by ELO closeness to the current course
        availableCourses.sort((a, b) => {
          const aEloDiff = Math.abs((a.eloScore || 1500) - (excludeCourse.eloScore || 1500));
          const bEloDiff = Math.abs((b.eloScore || 1500) - (excludeCourse.eloScore || 1500));
          return aEloDiff - bEloDiff;
        });
        
        // Get one of the 3 closest matches, with some randomness
        const closeMatches = availableCourses.slice(0, Math.min(3, availableCourses.length));
        return closeMatches[Math.floor(Math.random() * closeMatches.length)];
      }
    }
    
    // Fallback to random selection
    const randomIndex = Math.floor(Math.random() * availableCourses.length);
    return availableCourses[randomIndex];
  };

  // Import multiple courses
  const importCourses = (coursesToImport: CourseDatabase[]) => {
    // Add to imported courses list
    setImportedCourses(prev => [...prev, ...coursesToImport]);
    
    // Don't automatically add imported courses to user's collection
  };
  
  // Save recent search
  const saveRecentSearch = (searchTerm: string) => {
    if (!searchTerm || searchTerm.length < 2) return;
    
    setRecentSearches(prev => {
      // Remove if exists already
      const filtered = prev.filter(term => term.toLowerCase() !== searchTerm.toLowerCase());
      
      // Add to start, limit to 5 items
      return [searchTerm, ...filtered].slice(0, 5);
    });
  };
  
  // Get recent searches
  const getRecentSearches = () => recentSearches;
  
  // Set a course rating (1-10)
  const setCourseRating = (courseId: string, rating: number) => {
    const ratingEvent: CourseRatingEvent = {
      courseId,
      rating,
      timestamp: new Date()
    };
    
    setCourseRatings(prev => [...prev, ratingEvent]);
    
    // Update course itself
    updateCourse(courseId, { 
      rating,
      played: true, // Rating a course marks it as played
      // Calculate ELO score based on rating (linear scaling)
      // 1 rating = 1000 ELO, 10 rating = 2000 ELO
      eloScore: 1000 + (rating * 100)
    });
  };

  // Save user profile
  const saveUserProfile = (profile: UserProfile) => {
    setUserProfile(profile);
  };

  // Check if user profile is complete (has at least name and email)
  const isProfileComplete = () => {
    return !!(userProfile && userProfile.name && userProfile.email);
  };

  return (
    <GolfCourseContext.Provider
      value={{
        courses,
        addCourse,
        addCourseFromDatabase,
        updateCourse,
        deleteCourse,
        searchCourses,
        getAllCourses,
        getPlayedCourses,
        getUnplayedCourses,
        getPlayedCoursesCount,
        getUnplayedCoursesCount,
        getRankedCourses,
        getCourseById,
        recordComparison,
        getRandomCourseForComparison,
        champion,
        setChampion,
        championComparisonCount,
        allCourses: [...golfCourseDatabase, ...importedCourses],
        importCourses,
        getRecentSearches,
        saveRecentSearch,
        setCourseRating,
        userProfile,
        saveUserProfile,
        isProfileComplete
      }}
    >
      {children}
    </GolfCourseContext.Provider>
  );
};

export const useGolfCourses = () => {
  const context = useContext(GolfCourseContext);
  if (!context) {
    throw new Error("useGolfCourses must be used within a GolfCourseProvider");
  }
  return context;
};