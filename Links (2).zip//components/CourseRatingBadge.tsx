import React from "react";

interface CourseRatingBadgeProps {
  rating: number;
  size?: "sm" | "md" | "lg";
  animate?: boolean;
  className?: string;
}

export const CourseRatingBadge: React.FC<CourseRatingBadgeProps> = ({
  rating,
  size = "md",
  animate = false,
  className = ""
}) => {
  const sizeClasses = {
    sm: "w-8 h-8 text-xs",
    md: "w-10 h-10 text-base",
    lg: "w-12 h-12 text-lg"
  };
  
  const getColorClass = () => {
    if (rating >= 9) return "bg-[#FFD700] text-black"; // Gold
    if (rating >= 7) return "bg-[#4CAF50] text-white"; // Green
    if (rating >= 5) return "bg-[#2196F3] text-white"; // Blue
    if (rating >= 3) return "bg-[#FF9800] text-white"; // Orange
    return "bg-[#F44336] text-white"; // Red
  };
  
  return (
    <div 
      className={`rating-badge ${sizeClasses[size]} ${getColorClass()} ${animate ? 'animate-bounceIn' : ''} ${className}`}
    >
      {rating.toFixed(1)}
    </div>
  );
};