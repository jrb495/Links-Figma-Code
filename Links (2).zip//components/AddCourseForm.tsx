import React, { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Checkbox } from "./ui/checkbox";
import { useGolfCourses } from "./GolfCourseContext";

export const AddCourseForm: React.FC = () => {
  const { addCourse } = useGolfCourses();
  const [formData, setFormData] = useState({
    name: "",
    location: "",
    imageUrl: "",
    notes: ""
  });
  const [hasPlayed, setHasPlayed] = useState(true);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Use a default golf course image if none is provided
    const imageUrl = formData.imageUrl || "https://images.unsplash.com/photo-1587174486073-ae5e5cff23aa?q=80&w=2070&auto=format&fit=crop";
    
    addCourse({
      ...formData,
      imageUrl
    }, hasPlayed);
    
    // Reset form
    setFormData({
      name: "",
      location: "",
      imageUrl: "",
      notes: ""
    });
    setHasPlayed(true);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-primary mb-2">Add a Course</h2>
        <p className="text-secondary-foreground">Add details about a golf course you've played or want to play</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 bg-card/50 p-6 rounded-lg border border-primary/10 shadow-sm">
        <div>
          <label htmlFor="name" className="block mb-1">Course Name</label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Augusta National Golf Club"
            required
            className="bg-background"
          />
        </div>
        
        <div>
          <label htmlFor="location" className="block mb-1">Location</label>
          <Input
            id="location"
            name="location"
            value={formData.location}
            onChange={handleChange}
            placeholder="Augusta, GA"
            required
            className="bg-background"
          />
        </div>
        
        <div>
          <label htmlFor="imageUrl" className="block mb-1">Image URL (optional)</label>
          <Input
            id="imageUrl"
            name="imageUrl"
            value={formData.imageUrl}
            onChange={handleChange}
            placeholder="https://example.com/image.jpg"
            className="bg-background"
          />
        </div>
        
        <div>
          <label htmlFor="notes" className="block mb-1">Notes (optional)</label>
          <Textarea
            id="notes"
            name="notes"
            value={formData.notes}
            onChange={handleChange}
            placeholder="Your thoughts about this course..."
            rows={3}
            className="bg-background"
          />
        </div>

        <div className="flex items-center space-x-2 mt-2">
          <Checkbox 
            id="hasPlayed" 
            checked={hasPlayed} 
            onCheckedChange={(checked) => setHasPlayed(checked === true)} 
            className="data-checked:bg-primary data-checked:text-primary-foreground border-secondary"
          />
          <label
            htmlFor="hasPlayed"
            className="leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            I have played this course (only played courses are ranked)
          </label>
        </div>
        
        <Button 
          type="submit" 
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mt-2"
        >
          Add Course
        </Button>
      </form>

      <div className="bg-secondary/20 p-4 rounded-lg border border-secondary/40">
        <h4 className="text-secondary-foreground mb-2">How Links Works</h4>
        <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
          <li>Only courses you've actually played will be included in the rankings</li>
          <li>You can track courses you haven't played yet on your wishlist</li>
          <li>To rank a course, go to the "Compare Courses" tab</li>
          <li>When a course wins a comparison, it becomes the "champion"</li>
          <li>The champion will continue to be compared against other courses</li>
        </ul>
      </div>
    </div>
  );
};