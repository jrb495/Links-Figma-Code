export interface GolfCourse {
  id: string;
  name: string;
  location: string;
  imageUrl: string;
  dateAdded: Date;
  notes?: string;
  rank?: number;
  played: boolean; // Indicates if the user has actually played this course
  rating?: number; // Rating from 1-10
  comparisonCount: number; // Number of times this course has been compared
  dateRanked?: Date; // When the course was officially ranked (after 5 comparisons)
  
  // New characteristics
  courseStyle?: string; // Links, Parkland, Desert, etc.
  roundsPlayed?: number; // How many rounds the user has played
  bestScore?: number; // User's best score on this course
  playingPartners?: string[]; // People the user has played with
  par?: number; // Course par
  difficulty?: number; // Course difficulty rating (1-10)
  favorite?: boolean; // If this is a favorite course
  yearBuilt?: number; // Year the course was built
  designer?: string; // Course designer/architect
  eloScore?: number; // ELO rating score (default 1500)
}

export type ComparisonResult = {
  winnerId: string;
  loserId: string;
  timestamp: Date;
};

export type CourseDatabase = {
  id: string;
  name: string;
  location: string;
  imageUrl?: string;
  description?: string;
  keywords?: string[]; // Added keywords field for better search
  courseStyle?: string; // Links, Parkland, Desert, etc.
  par?: number; // Course par
  difficulty?: number; // Course difficulty rating (1-10)
  yearBuilt?: number; // Year the course was built
  designer?: string; // Course designer/architect
};

export interface CourseRatingEvent {
  courseId: string;
  rating: number;
  timestamp: Date;
}

export interface PlayingRound {
  courseId: string;
  date: Date;
  score: number;
  partners: string[];
  notes?: string;
}

export interface UserProfile {
  name: string;
  email: string;
  location?: string;
  handicap?: string;
  bio?: string;
  favoriteCourseName?: string;
  favoriteCourseLoc?: string;
  favoriteImage?: string;
  yearsPlaying?: string;
  dateCreated?: Date;
  dateUpdated?: Date;
}