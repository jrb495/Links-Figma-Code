import React, { useState, useEffect } from "react";
import { CourseRatingBadge } from "./CourseRatingBadge";
import { Dialog } from "./ui/dialog";
import { GolfCourse } from "./types";

interface CourseRatingAnimationProps {
  course: GolfCourse;
  open: boolean;
  onClose: () => void;
}

export const CourseRatingAnimation: React.FC<CourseRatingAnimationProps> = ({
  course,
  open,
  onClose
}) => {
  const [stage, setStage] = useState(0);
  
  // Progress through animation stages
  useEffect(() => {
    if (!open) return;
    
    const timer1 = setTimeout(() => setStage(1), 500);
    const timer2 = setTimeout(() => setStage(2), 1500);
    const timer3 = setTimeout(() => {
      setStage(3);
      setTimeout(onClose, 1500);
    }, 3000);
    
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [open, onClose]);
  
  if (!open) return null;
  
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
        <div className="bg-card rounded-lg p-6 w-full max-w-md mx-4 text-center shadow-xl animate-fadeInScale">
          <div className="flex flex-col items-center space-y-4">
            <div className={`transition-opacity duration-500 ${stage >= 0 ? 'opacity-100' : 'opacity-0'}`}>
              <div className="rounded-lg overflow-hidden h-40 w-full">
                <img 
                  src={course.imageUrl} 
                  alt={course.name} 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
            
            <h3 className={`text-primary text-xl transition-all duration-500 ${stage >= 1 ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              {course.name} has been ranked!
            </h3>
            
            {stage >= 2 && (
              <div className="animate-bounceIn">
                <CourseRatingBadge rating={course.rating || 5} size="lg" animate={true} />
                
                <p className="mt-4 text-secondary-foreground animate-slideInTop">
                  This course has been added to your collection with a rating of <strong>{course.rating?.toFixed(1)}</strong>.
                </p>
              </div>
            )}
            
            {stage >= 3 && (
              <button
                onClick={onClose}
                className="mt-2 bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 animate-slideInTop"
              >
                Continue
              </button>
            )}
          </div>
        </div>
      </div>
    </Dialog>
  );
};