import React, { useState, useEffect } from 'react';
import { CourseDatabase, GolfCourse } from './types';
import { useGolfCourses } from './GolfCourseContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';

interface InitialRatingsProps {
  onComplete?: (view: string) => void;
}

export const InitialRatings: React.FC<InitialRatingsProps> = ({ onComplete }) => {
  const { 
    searchCourses, 
    addCourseFromDatabase, 
    getPlayedCoursesCount,
    setCourseRating 
  } = useGolfCourses();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<CourseDatabase[]>([]);
  const [selectedCourses, setSelectedCourses] = useState<GolfCourse[]>([]);
  const [ratingsComplete, setRatingsComplete] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [currentRatingCourse, setCurrentRatingCourse] = useState<GolfCourse | null>(null);
  const [currentRating, setCurrentRating] = useState(7);
  
  // Check if user already has rated courses
  const hasRatedCourses = getPlayedCoursesCount() > 0;
  
  useEffect(() => {
    // Show welcome dialog on first visit if no courses are rated
    if (!hasRatedCourses) {
      setTimeout(() => {
        setDialogOpen(true);
      }, 500);
    }
  }, [hasRatedCourses]);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      const results = searchCourses(searchQuery);
      setSearchResults(results);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const addCourse = (courseData: CourseDatabase) => {
    // Check if course already selected
    if (selectedCourses.some(course => course.id === courseData.id)) {
      return;
    }
    
    const course = addCourseFromDatabase(courseData.id);
    
    if (course) {
      setSelectedCourses(prev => {
        if (prev.length >= 5) {
          return [...prev.slice(1), course];
        }
        return [...prev, course];
      });
    }
  };

  const removeCourse = (courseId: string) => {
    setSelectedCourses(prev => prev.filter(course => course.id !== courseId));
  };

  const startRatingProcess = () => {
    if (selectedCourses.length > 0) {
      setCurrentRatingCourse(selectedCourses[0]);
      setDialogOpen(true);
    }
  };

  const handleRating = () => {
    if (currentRatingCourse) {
      setCourseRating(currentRatingCourse.id, currentRating);
      
      const nextIndex = selectedCourses.findIndex(c => c.id === currentRatingCourse.id) + 1;
      
      if (nextIndex < selectedCourses.length) {
        setCurrentRatingCourse(selectedCourses[nextIndex]);
        setCurrentRating(7); // Reset to default
      } else {
        setCurrentRatingCourse(null);
        setRatingsComplete(true);
      }
    }
  };

  const handleComplete = () => {
    // Update the URL for bookmarking purposes
    window.history.pushState({}, "", "/?view=rankings");
    
    // Use the onComplete callback to inform the parent component to change the view
    if (onComplete) {
      onComplete("rankings");
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-primary mb-2">Initial Course Ratings</h2>
        <p className="text-secondary-foreground">
          To get started, please select and rate 5 golf courses you've played. 
          These will serve as the baseline for your future course rankings.
        </p>
      </div>

      {!ratingsComplete ? (
        <>
          <div className="bg-accent/30 p-4 rounded-lg border border-primary/20">
            <h3 className="text-primary mb-2">Selected Courses: {selectedCourses.length}/5</h3>
            
            <div className="grid gap-3 mt-4">
              {selectedCourses.map(course => (
                <div key={course.id} className="flex items-center gap-3 bg-card p-2 rounded-lg border">
                  <div className="w-12 h-12 rounded-md overflow-hidden">
                    <ImageWithFallback
                      src={course.imageUrl}
                      alt={course.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-primary">{course.name}</h4>
                    <p className="text-xs text-secondary-foreground">{course.location}</p>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => removeCourse(course.id)}
                    className="text-red-500 hover:text-red-600 hover:bg-red-100"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M3 6h18"></path>
                      <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"></path>
                      <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path>
                    </svg>
                  </Button>
                </div>
              ))}

              {selectedCourses.length < 5 && (
                <div className="flex items-center justify-center gap-2 p-3 border border-dashed border-primary/30 rounded-lg bg-accent/10">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary/60">
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 8v8"></path>
                    <path d="M8 12h8"></path>
                  </svg>
                  <span className="text-sm text-primary/60">
                    Add {5 - selectedCourses.length} more course{selectedCourses.length === 4 ? '' : 's'}
                  </span>
                </div>
              )}
            </div>
            
            {selectedCourses.length === 5 && (
              <div className="mt-4">
                <Button
                  onClick={startRatingProcess}
                  className="w-full bg-primary text-primary-foreground"
                >
                  Start Rating These Courses
                </Button>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Search for courses you've played..."
                className="bg-background"
              />
              <Button 
                onClick={handleSearch}
                className="bg-primary text-primary-foreground whitespace-nowrap"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                  <circle cx="11" cy="11" r="8"></circle>
                  <path d="m21 21-4.3-4.3"></path>
                </svg>
                Search
              </Button>
            </div>

            {searchResults.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {searchResults.map(course => (
                  <Card key={course.id} className="overflow-hidden border hover:border-primary/30 transition-colors">
                    <div className="h-28 overflow-hidden">
                      <ImageWithFallback
                        src={course.imageUrl || "https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9?q=80&w=2070&auto=format&fit=crop"}
                        alt={course.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="p-3">
                      <h4 className="text-primary">{course.name}</h4>
                      <p className="text-xs text-secondary-foreground mb-3">{course.location}</p>
                      <Button
                        onClick={() => addCourse(course)}
                        size="sm"
                        className="w-full bg-primary text-primary-foreground"
                        disabled={selectedCourses.some(c => c.id === course.id)}
                      >
                        {selectedCourses.some(c => c.id === course.id) ? 'Added' : 'Add Course'}
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            ) : searchQuery ? (
              <div className="text-center p-6 bg-accent/20 rounded-lg border border-primary/10">
                <p className="text-secondary-foreground">No courses found. Try a different search term.</p>
              </div>
            ) : (
              <div className="text-center p-6 bg-accent/20 rounded-lg border border-primary/10">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-2 text-primary/60">
                  <circle cx="11" cy="11" r="8"></circle>
                  <path d="m21 21-4.3-4.3"></path>
                </svg>
                <p className="text-secondary-foreground">Search for golf courses you've played before</p>
                <p className="text-xs text-muted-foreground mt-2">Try searching for courses by name or location (e.g., "Augusta", "St. Andrews", or "Pebble Beach")</p>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="text-center p-8 bg-accent/30 rounded-lg border border-primary/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-4 text-primary/80">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <polyline points="22 4 12 14.01 9 11.01"></polyline>
          </svg>
          <h3 className="text-xl text-primary mb-2">Initial Ratings Complete!</h3>
          <p className="text-secondary-foreground mb-4">
            You've successfully rated your first 5 courses. These will serve as the baseline for your rankings.
          </p>
          <Button 
            onClick={handleComplete} 
            className="bg-primary text-primary-foreground"
          >
            View My Rankings
          </Button>
        </div>
      )}

      {/* Rating Dialog */}
      <Dialog open={dialogOpen && currentRatingCourse !== null} onOpenChange={(open) => !ratingsComplete && setDialogOpen(open)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center text-primary">Rate This Course</DialogTitle>
            <DialogDescription className="text-center">
              Rate this course on a scale from 1 to 10
            </DialogDescription>
          </DialogHeader>
          
          {currentRatingCourse && (
            <div className="flex flex-col items-center space-y-4 py-4">
              <div className="w-24 h-24 rounded-lg overflow-hidden">
                <ImageWithFallback
                  src={currentRatingCourse.imageUrl}
                  alt={currentRatingCourse.name}
                  className="w-full h-full object-cover"
                />
              </div>
              
              <h3 className="text-lg text-primary">{currentRatingCourse.name}</h3>
              <p className="text-secondary-foreground">{currentRatingCourse.location}</p>
              
              <div className="w-full max-w-xs mt-4">
                <div className="flex justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Poor</span>
                  <span className="text-sm text-muted-foreground">Excellent</span>
                </div>
                
                <div className="grid grid-cols-10 gap-1 mb-4">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(rating => (
                    <button
                      key={rating}
                      className={`h-12 rounded-md transition-all ${
                        rating === currentRating 
                          ? 'bg-primary scale-110 shadow-md' 
                          : rating < currentRating 
                              ? 'bg-primary/60' 
                              : 'bg-primary/20'
                      }`}
                      onClick={() => setCurrentRating(rating)}
                    >
                      <span className={`font-medium ${rating === currentRating ? 'text-white' : 'text-primary-foreground/80'}`}>
                        {rating}
                      </span>
                    </button>
                  ))}
                </div>
                
                <Button 
                  onClick={handleRating}
                  className="w-full bg-primary text-primary-foreground"
                >
                  {selectedCourses.findIndex(c => c.id === currentRatingCourse.id) < selectedCourses.length - 1
                    ? 'Rate & Continue'
                    : 'Finish Rating'
                  }
                </Button>
              </div>
            </div>
          )}
          
          {/* Welcome Dialog Content */}
          {!currentRatingCourse && !ratingsComplete && (
            <div className="flex flex-col items-center space-y-4 py-4 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-primary/80">
                <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"></path>
              </svg>
              
              <DialogTitle className="text-lg text-primary">Welcome to Links!</DialogTitle>
              
              <DialogDescription className="text-secondary-foreground">
                To get started, please select and rate 5 golf courses you've played.
                These ratings will help us establish your baseline preferences.
              </DialogDescription>
              
              <Button 
                onClick={() => setDialogOpen(false)}
                className="bg-primary text-primary-foreground mt-4"
              >
                Get Started
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};