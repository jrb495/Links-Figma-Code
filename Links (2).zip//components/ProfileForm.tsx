import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Card } from './ui/card';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useGolfCourses } from './GolfCourseContext';
import { ScrollArea } from './ui/scroll-area';

interface UserProfile {
  name: string;
  location: string;
  handicap: string;
  bio: string;
  favoriteCourseName: string;
  favoriteCourseLoc: string;
  favoriteImage: string;
  email: string;
  yearsPlaying: string;
}

export const ProfileForm: React.FC = () => {
  const { userProfile, saveUserProfile } = useGolfCourses();
  const [profile, setProfile] = useState<UserProfile>({
    name: '',
    location: '',
    handicap: '',
    bio: '',
    favoriteCourseName: '',
    favoriteCourseLoc: '',
    favoriteImage: 'https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9',
    email: '',
    yearsPlaying: '',
  });
  const [isSaved, setIsSaved] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (userProfile) {
      setProfile(userProfile);
    }
  }, [userProfile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveUserProfile(profile);
    setIsSaved(true);
    setIsEditing(false);
    
    setTimeout(() => {
      setIsSaved(false);
    }, 3000);
  };

  // Check if profile has been set up
  const isProfileComplete = 
    profile.name && 
    profile.email;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-primary">Your Golf Profile</h2>
        {isProfileComplete && !isEditing && (
          <Button variant="outline" onClick={() => setIsEditing(true)}>
            Edit Profile
          </Button>
        )}
      </div>

      {!isProfileComplete || isEditing ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input 
                  id="name" 
                  name="name" 
                  value={profile.name} 
                  onChange={handleChange}
                  className="bg-background"
                  placeholder="Your name"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email" 
                  name="email" 
                  type="email"
                  value={profile.email} 
                  onChange={handleChange}
                  className="bg-background"
                  placeholder="Your email"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input 
                  id="location" 
                  name="location" 
                  value={profile.location} 
                  onChange={handleChange}
                  className="bg-background"
                  placeholder="City, State/Country"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="handicap">Handicap</Label>
                <Input 
                  id="handicap" 
                  name="handicap"
                  type="number"
                  min="-10"
                  max="54" 
                  value={profile.handicap} 
                  onChange={handleChange}
                  className="bg-background"
                  placeholder="Your handicap (e.g. 12.4)"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="yearsPlaying">Years Playing Golf</Label>
                <Input 
                  id="yearsPlaying" 
                  name="yearsPlaying"
                  type="number"
                  min="0"
                  max="80" 
                  value={profile.yearsPlaying} 
                  onChange={handleChange}
                  className="bg-background"
                  placeholder="How many years you've been playing"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="favoriteCourseName">Favorite Course Name</Label>
                <Input 
                  id="favoriteCourseName" 
                  name="favoriteCourseName" 
                  value={profile.favoriteCourseName} 
                  onChange={handleChange}
                  className="bg-background"
                  placeholder="Your favorite golf course"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="favoriteCourseLoc">Favorite Course Location</Label>
              <Input 
                id="favoriteCourseLoc" 
                name="favoriteCourseLoc" 
                value={profile.favoriteCourseLoc} 
                onChange={handleChange}
                className="bg-background"
                placeholder="Location of your favorite golf course"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">About You</Label>
              <Textarea 
                id="bio" 
                name="bio" 
                value={profile.bio} 
                onChange={handleChange}
                className="bg-background h-32"
                placeholder="Tell us about yourself as a golfer..."
              />
            </div>
          </div>
          
          <div className="flex justify-end">
            {isEditing && (
              <Button 
                type="button" 
                variant="outline" 
                className="mr-2"
                onClick={() => {
                  setIsEditing(false);
                  if (userProfile) {
                    setProfile(userProfile);
                  }
                }}
              >
                Cancel
              </Button>
            )}
            <Button type="submit" className="bg-primary text-primary-foreground">
              {isEditing ? 'Save Changes' : 'Create Profile'}
            </Button>
          </div>
        </form>
      ) : (
        <div className="space-y-6">
          {isSaved && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4 animate-fadeInScale">
              Profile saved successfully!
            </div>
          )}
          
          <Card className="overflow-hidden">
            <div className="p-6 pb-0">
              <div className="flex flex-col md:flex-row gap-4 items-center md:items-start">
                <Avatar className="w-24 h-24 border-2 border-primary/20">
                  <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(profile.name)}`} />
                  <AvatarFallback className="text-3xl bg-accent">
                    {profile.name?.charAt(0) || '?'}
                  </AvatarFallback>
                </Avatar>

                <div className="space-y-2 text-center md:text-left flex-1">
                  <h3 className="text-primary">{profile.name}</h3>
                  {profile.location && (
                    <p className="text-secondary-foreground">{profile.location}</p>
                  )}
                  <div className="flex flex-wrap justify-center md:justify-start gap-2 mt-2">
                    {profile.handicap && (
                      <span className="bg-accent/50 text-accent-foreground px-2 py-1 rounded-md text-sm">
                        Handicap: {profile.handicap}
                      </span>
                    )}
                    {profile.yearsPlaying && (
                      <span className="bg-accent/50 text-accent-foreground px-2 py-1 rounded-md text-sm">
                        {profile.yearsPlaying} {parseInt(profile.yearsPlaying) === 1 ? 'year' : 'years'} playing
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {profile.bio && (
                <div className="space-y-2">
                  <h4 className="text-primary font-medium">About</h4>
                  <p className="text-secondary-foreground">{profile.bio}</p>
                </div>
              )}

              <div className="space-y-2">
                <h4 className="text-primary font-medium">Contact</h4>
                <p className="text-secondary-foreground">{profile.email}</p>
              </div>

              {profile.favoriteCourseName && (
                <div className="space-y-2">
                  <h4 className="text-primary font-medium">Favorite Course</h4>
                  <div className="flex items-center gap-3 bg-accent/20 p-3 rounded-lg">
                    <div className="w-16 h-16 rounded-md overflow-hidden">
                      <ImageWithFallback
                        src={profile.favoriteImage}
                        alt={profile.favoriteCourseName}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-medium text-primary">{profile.favoriteCourseName}</p>
                      {profile.favoriteCourseLoc && (
                        <p className="text-sm text-secondary-foreground">{profile.favoriteCourseLoc}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
};