import React, { useState, useEffect } from "react";
import { useGolfCourses } from "./GolfCourseContext";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { GolfCourse } from "./types";
import { CourseRatingBadge } from "./CourseRatingBadge";
import { CourseDetails } from "./CourseDetails";

export const RankingsList: React.FC = () => {
  const { getRankedCourses, getPlayedCourses } = useGolfCourses();
  const [selectedCourse, setSelectedCourse] = useState<GolfCourse | null>(null);
  const [sortBy, setSortBy] = useState<'rank' | 'rating' | 'name'>('rank');
  const [searchQuery, setSearchQuery] = useState('');
  
  const playedCourses = getPlayedCourses();
  const rankedCourses = getRankedCourses();
  
  // Filter courses based on search query
  const filteredCourses = searchQuery.trim() 
    ? playedCourses.filter(course => 
        course.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        course.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (course.courseStyle && course.courseStyle.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : playedCourses;
    
  // Sort courses based on selected sort method
  const sortedCourses = [...filteredCourses].sort((a, b) => {
    if (sortBy === 'rank') {
      return (a.rank || Infinity) - (b.rank || Infinity);
    } else if (sortBy === 'rating') {
      return (b.rating || 0) - (a.rating || 0);
    } else { // name
      return a.name.localeCompare(b.name);
    }
  });
  
  // Clear search when changing sort method
  useEffect(() => {
    setSearchQuery('');
  }, [sortBy]);
  
  if (selectedCourse) {
    return (
      <CourseDetails
        course={selectedCourse}
        onBack={() => setSelectedCourse(null)}
      />
    );
  }

  if (playedCourses.length === 0) {
    return (
      <div className="p-8 rounded-lg bg-accent/30 shadow text-center border border-primary/20">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-primary/70 mb-4">
          <path d="M18 8c0 2-2 2-2 4v10"></path>
          <path d="M7 8a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v0a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1v0Z"></path>
          <path d="M6 12a1 1 0 0 1 1-1h7a1 1 0 0 1 1 1v0a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v0Z"></path>
        </svg>
        <h2 className="text-primary mb-2">No Courses Yet</h2>
        <p className="text-secondary-foreground">You haven't added any courses to your collection yet.</p>
        <div className="flex gap-2 justify-center mt-4">
          <Button 
            onClick={() => window.history.pushState({}, "", "/?view=search")}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            Find Courses
          </Button>
          <Button 
            variant="outline" 
            onClick={() => window.history.pushState({}, "", "/?view=add")}
            className="border-primary/30 text-primary"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M12 5v14"></path>
              <path d="M5 12h14"></path>
            </svg>
            Add Course
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-primary mb-2">My Courses</h2>
        <p className="text-secondary-foreground">
          Your personal collection of golf courses you've played and ranked
        </p>
      </div>
      
      {/* Search Bar */}
      <div className="relative">
        <Input
          placeholder="Search your courses..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="bg-background pr-8"
        />
        {searchQuery && (
          <button 
            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary"
            onClick={() => setSearchQuery('')}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M18 6 6 18"></path>
              <path d="m6 6 12 12"></path>
            </svg>
          </button>
        )}
      </div>
      
      <div className="flex justify-between items-center">
        <div className="flex gap-2">
          <Button
            variant={sortBy === 'rank' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSortBy('rank')}
            className={sortBy === 'rank' ? 'bg-primary text-primary-foreground' : 'border-primary/30 text-primary'}
          >
            By Rank
          </Button>
          <Button
            variant={sortBy === 'rating' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSortBy('rating')}
            className={sortBy === 'rating' ? 'bg-primary text-primary-foreground' : 'border-primary/30 text-primary'}
          >
            By Rating
          </Button>
          <Button
            variant={sortBy === 'name' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setSortBy('name')}
            className={sortBy === 'name' ? 'bg-primary text-primary-foreground' : 'border-primary/30 text-primary'}
          >
            By Name
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          {sortedCourses.length} {sortedCourses.length === 1 ? 'course' : 'courses'}
          {searchQuery && ` (filtered from ${playedCourses.length})`}
        </p>
      </div>

      {sortedCourses.length > 0 ? (
        <div className="space-y-4">
          {sortedCourses.map((course) => (
            <Card 
              key={course.id} 
              className="overflow-hidden border border-secondary/30 hover:border-primary/30 transition-all bg-card cursor-pointer"
              onClick={() => setSelectedCourse(course)}
            >
              <div className="flex flex-col sm:flex-row">
                <div className="sm:w-36 h-28 sm:h-auto">
                  <ImageWithFallback
                    src={course.imageUrl}
                    alt={course.name}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="p-4 flex-1 relative">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-primary mb-1 group-hover:text-primary">
                        {sortBy === 'rank' && course.rank ? <span className="font-bold mr-2">#{course.rank}</span> : ''}
                        {course.name}
                      </h3>
                      <p className="text-secondary-foreground text-sm">{course.location}</p>
                      
                      <div className="flex flex-wrap gap-2 mt-3">
                        {course.courseStyle && (
                          <span className="inline-flex items-center rounded-full border border-primary/20 px-2.5 py-0.5 text-xs font-medium text-primary">
                            {course.courseStyle}
                          </span>
                        )}
                        {course.roundsPlayed && course.roundsPlayed > 0 && (
                          <span className="inline-flex items-center rounded-full border border-primary/20 px-2.5 py-0.5 text-xs font-medium text-primary">
                            {course.roundsPlayed} rounds
                          </span>
                        )}
                        {course.bestScore && (
                          <span className="inline-flex items-center rounded-full border border-primary/20 px-2.5 py-0.5 text-xs font-medium text-primary">
                            Best: {course.bestScore}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {course.rating && (
                      <CourseRatingBadge rating={course.rating} />
                    )}
                  </div>
                  
                  <div className="absolute bottom-3 right-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary/50">
                      <path d="m9 18 6-6-6-6"></path>
                    </svg>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center p-6 bg-accent/20 rounded-lg border border-primary/10">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-primary/70 mb-2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
            <path d="M8 11h6"></path>
          </svg>
          <h3 className="text-primary mb-1">No Matching Courses</h3>
          <p className="text-secondary-foreground">
            No courses match your search criteria
          </p>
          <Button
            variant="outline"
            onClick={() => setSearchQuery("")}
            className="mt-4 border-primary/30 text-primary"
          >
            Clear Search
          </Button>
        </div>
      )}
      
      <div className="flex justify-center mt-4">
        <Button
          variant="outline"
          onClick={() => window.history.pushState({}, "", "/?view=search")}
          className="border-primary/30 text-primary"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          Find More Courses
        </Button>
      </div>
    </div>
  );
};