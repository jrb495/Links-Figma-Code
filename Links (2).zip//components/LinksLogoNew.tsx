import React from 'react';

interface LinksLogoNewProps {
  className?: string;
  showTagline?: boolean;
}

export const LinksLogoNew: React.FC<LinksLogoNewProps> = ({ 
  className = "h-12 w-auto", 
  showTagline = false 
}) => {
  return (
    <div className={`flex flex-col items-center ${className}`}>
      <svg 
        viewBox="0 0 200 200" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto"
      >
        {/* Circle background */}
        <circle cx="100" cy="70" r="60" fill="#000" />
        
        {/* Green arc */}
        <path d="M160 70C160 102.033 134.033 128 102 128C69.9675 128 44 102.033 44 70" stroke="#2a6d40" strokeWidth="16" />
        
        {/* Golf ball */}
        <circle cx="100" cy="70" r="28" fill="white" />
        
        {/* Golf ball dimples */}
        <circle cx="90" cy="60" r="3" fill="#000" />
        <circle cx="100" cy="60" r="3" fill="#000" />
        <circle cx="110" cy="60" r="3" fill="#000" />
        <circle cx="85" cy="70" r="3" fill="#000" />
        <circle cx="95" cy="70" r="3" fill="#000" />
        <circle cx="105" cy="70" r="3" fill="#000" />
        <circle cx="115" cy="70" r="3" fill="#000" />
        <circle cx="90" cy="80" r="3" fill="#000" />
        <circle cx="100" cy="80" r="3" fill="#000" />
        <circle cx="110" cy="80" r="3" fill="#000" />
        
        {/* Flag */}
        <path d="M100 30L100 10" stroke="#000" strokeWidth="3" />
        <path d="M100 10L115 15L100 20" fill="#000" />
        
        {/* Golf course grid pattern */}
        <rect x="70" y="90" width="8" height="8" fill="#f7f5e8" />
        <rect x="80" y="90" width="8" height="8" fill="#f7f5e8" />
        <rect x="90" y="90" width="8" height="8" fill="#f7f5e8" />
        <rect x="100" y="90" width="8" height="8" fill="#f7f5e8" />
        <rect x="110" y="90" width="8" height="8" fill="#f7f5e8" />
        <rect x="120" y="90" width="8" height="8" fill="#f7f5e8" />
        
        <rect x="70" y="100" width="8" height="8" fill="#f7f5e8" />
        <rect x="80" y="100" width="8" height="8" fill="#f7f5e8" />
        <rect x="90" y="100" width="8" height="8" fill="#f7f5e8" />
        <rect x="100" y="100" width="8" height="8" fill="#f7f5e8" />
        <rect x="110" y="100" width="8" height="8" fill="#f7f5e8" />
        <rect x="120" y="100" width="8" height="8" fill="#f7f5e8" />
        
        {/* Golf Tee */}
        <path d="M100 100L100 130" stroke="#000" strokeWidth="8" strokeLinecap="round" />
      </svg>
      
      {/* "Links" text */}
      <div className="text-primary font-bold text-[calc(var(--font-size)*2)] leading-none tracking-tight mt-2">Links</div>
      
      {/* Optional tagline */}
      {showTagline && (
        <div className="text-primary uppercase tracking-widest text-[0.7em] mt-1">SOCIAL SCORECARD</div>
      )}
      
      {/* Decoration elements */}
      {showTagline && (
        <div className="flex items-center gap-2 mt-1">
          <div className="w-2 h-2 rounded-full bg-primary"></div>
          <div className="w-1 h-4 bg-primary"></div>
          <div className="w-2 h-4 bg-primary"></div>
          <div className="w-1 h-4 bg-primary"></div>
          <div className="w-2 h-2 rounded-full bg-primary"></div>
        </div>
      )}
    </div>
  );
};