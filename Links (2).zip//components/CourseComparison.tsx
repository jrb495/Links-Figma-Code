import React, { useState, useEffect } from "react";
import { useGolfCourses } from "./GolfCourseContext";
import { GolfCourse } from "./types";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { CourseRatingBadge } from "./CourseRatingBadge";
import { CourseRatingAnimation } from "./CourseRatingAnimation";

export const CourseComparison: React.FC = () => {
  const {
    getCourseById,
    getRandomCourseForComparison,
    recordComparison,
    champion,
    setChampion,
    championComparisonCount,
    getAllCourses,
    getPlayedCoursesCount
  } = useGolfCourses();

  const [leftCourse, setLeftCourse] = useState<GolfCourse | null>(null);
  const [rightCourse, setRightCourse] = useState<GolfCourse | null>(null);
  const [winningCourse, setWinningCourse] = useState<GolfCourse | null>(null);
  const [animationComplete, setAnimationComplete] = useState(false);
  const [comparisonCount, setComparisonCount] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const [remainingComparisons, setRemainingComparisons] = useState(5);
  
  const hasMinimumPlayedCourses = getPlayedCoursesCount() >= 5;
  const hasAnyCourses = getAllCourses().length > 0;

  // Initialize the comparison
  useEffect(() => {
    const initializeComparison = () => {
      if (!hasAnyCourses) return;

      // If we have a champion, use it as the left course
      if (champion) {
        const championCourse = getCourseById(champion);
        if (championCourse) {
          setLeftCourse(championCourse);
          setComparisonCount(championComparisonCount);
          setRemainingComparisons(5 - championComparisonCount);
          
          // Get a challenger course that has similar ranking
          const challenger = getRandomCourseForComparison(champion, true);
          if (challenger) {
            setRightCourse(challenger);
          }
          return;
        }
      }

      // Otherwise, pick two random courses
      const allCourses = getAllCourses();
      if (allCourses.length < 2) return;
      
      // Pick a course
      const firstCourse = allCourses[Math.floor(Math.random() * allCourses.length)];
      setLeftCourse(firstCourse);
      setChampion(firstCourse.id);
      setComparisonCount(0);
      setRemainingComparisons(5);
      
      // Get a challenger
      const secondCourse = getRandomCourseForComparison(firstCourse.id);
      setRightCourse(secondCourse);
    };

    initializeComparison();
  }, [champion, championComparisonCount, getCourseById, getRandomCourseForComparison, setChampion, hasAnyCourses, getAllCourses]);

  // Handle course selection
  const handleCourseSelection = (selectedCourse: "left" | "right") => {
    if (!leftCourse || !rightCourse) return;

    const winner = selectedCourse === "left" ? leftCourse : rightCourse;
    const loser = selectedCourse === "left" ? rightCourse : leftCourse;

    setWinningCourse(winner);
    
    // Record the comparison
    recordComparison(winner.id, loser.id);
    
    // Increment comparison count if the current champion won
    const newCount = (champion === winner.id) 
      ? comparisonCount + 1 
      : 1; // Reset to 1 if we have a new champion
    
    setComparisonCount(newCount);
    setRemainingComparisons(5 - newCount);
    
    // If the challenger won, make it the new champion
    if (champion !== winner.id) {
      setChampion(winner.id);
    }
  };

  // Handle animation completion
  const handleAnimationComplete = () => {
    setAnimationComplete(true);

    // Check if we've reached 5 comparisons with this champion
    if (comparisonCount >= 5) {
      setIsComplete(true);
      return;
    }

    // Keep the champion on the left (or winner)
    if (winningCourse) {
      setLeftCourse(winningCourse);
      
      // Get a new challenger with similar ranking
      const newChallenger = getRandomCourseForComparison(winningCourse.id, true);
      setRightCourse(newChallenger);
      
      // Reset animation states
      setWinningCourse(null);
      setAnimationComplete(false);
    }
  };

  // Handle "continue" after completing 5 comparisons
  const handleContinue = () => {
    // Reset the champion
    setChampion(null);
    setComparisonCount(0);
    setRemainingComparisons(5);
    setIsComplete(false);
    setWinningCourse(null);
    
    // Force page reload to go back to add view
    window.history.pushState({}, "", "/?view=rankings");
    window.location.reload();
  };

  // If we don't have enough played courses for rankings, show prompt for initial ratings
  if (!hasMinimumPlayedCourses && hasAnyCourses) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-primary mb-2">Course Comparison</h2>
          <p className="text-secondary-foreground">
            Rate at least 5 courses to establish your baseline preferences
          </p>
        </div>
        
        <div className="p-8 rounded-lg bg-accent/30 text-center border border-primary/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-4 text-primary/70">
            <path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"></path>
          </svg>
          
          <h3 className="text-lg text-primary mb-2">Initial Ratings Needed</h3>
          <p className="text-secondary-foreground mb-4">
            Before comparing courses, you need to rate at least 5 courses to establish your baseline preferences.
          </p>
          
          <Button 
            onClick={() => window.history.pushState({}, "", "/?view=initial")}
            className="bg-primary text-primary-foreground"
          >
            Rate Initial Courses
          </Button>
        </div>
      </div>
    );
  }
  
  if (!hasAnyCourses) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-primary mb-2">Course Comparison</h2>
          <p className="text-secondary-foreground">
            Compare courses to build your personalized rankings
          </p>
        </div>
        
        <div className="p-8 rounded-lg bg-accent/30 text-center border border-primary/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-4 text-primary/70">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          
          <h3 className="text-lg text-primary mb-2">No Courses Yet</h3>
          <p className="text-secondary-foreground mb-4">
            You need to add some courses before you can start comparing them.
          </p>
          
          <div className="flex gap-2 justify-center">
            <Button 
              onClick={() => window.history.pushState({}, "", "/?view=search")}
              className="bg-primary text-primary-foreground"
            >
              Search Courses
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => window.history.pushState({}, "", "/?view=add")}
              className="border-primary/30 text-primary"
            >
              Add Course
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (isComplete) {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-primary mb-2">Ranking Complete!</h2>
          <p className="text-secondary-foreground">
            You've completed 5 comparisons with this course.
          </p>
        </div>
        
        <div className="p-8 rounded-lg bg-accent/30 text-center border border-primary/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto mb-4 text-primary/70">
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <polyline points="22 4 12 14.01 9 11.01"></polyline>
          </svg>
          
          {leftCourse && (
            <div className="flex justify-center mb-4">
              <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-primary shadow-lg">
                <ImageWithFallback
                  src={leftCourse.imageUrl}
                  alt={leftCourse.name}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          )}
          
          <h3 className="text-lg text-primary mb-1">
            {leftCourse?.name}
          </h3>
          
          <p className="text-secondary-foreground mb-4">
            This course has been added to your rankings.
          </p>
          
          <div className="flex gap-2 justify-center">
            <Button 
              onClick={handleContinue}
              className="bg-primary text-primary-foreground"
            >
              View Rankings
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => {
                setChampion(null);
                setComparisonCount(0);
                setRemainingComparisons(5);
                setIsComplete(false);
                setWinningCourse(null);
              }}
              className="border-primary/30 text-primary"
            >
              Compare More Courses
            </Button>
          </div>
        </div>
      </div>
    );
  }

  if (!leftCourse || !rightCourse) {
    return (
      <div className="p-8 rounded-lg bg-accent/30 text-center border border-primary/20">
        <div className="animate-pulse">
          <div className="h-6 w-32 mb-3 bg-primary/30 rounded mx-auto"></div>
          <div className="h-4 w-64 bg-secondary/30 rounded mx-auto mb-6"></div>
          <div className="h-48 w-full max-w-md bg-primary/20 rounded-lg mx-auto"></div>
        </div>
      </div>
    );
  }

  if (winningCourse && !animationComplete) {
    return (
      <CourseRatingAnimation
        course={winningCourse}
        onComplete={handleAnimationComplete}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-primary mb-2">Compare Courses</h2>
        <p className="text-secondary-foreground">
          Which course do you prefer? {remainingComparisons} comparisons remaining with this course.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <ComparisonCard
          course={leftCourse}
          isChampion={true}
          onSelect={() => handleCourseSelection("left")}
        />
        <div className="flex items-center justify-center md:hidden">
          <span className="text-lg font-semibold text-primary">vs</span>
        </div>
        <ComparisonCard
          course={rightCourse}
          isChampion={false}
          onSelect={() => handleCourseSelection("right")}
        />
      </div>
      
      <div className="flex items-center justify-center mt-4">
        <Button 
          variant="outline" 
          className="border-primary/30 text-primary"
          onClick={() => {
            // Skip this comparison and get a new challenger
            const newChallenger = getRandomCourseForComparison(leftCourse.id, true);
            setRightCourse(newChallenger);
          }}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
            <path d="m15 15 6 6m-6 0 6-6"></path>
            <path d="M14.5 8.5 19 4m-4.5 8.5L19 17"></path>
            <path d="M4 4v16"></path>
            <path d="M9 4v16"></path>
          </svg>
          Skip This Comparison
        </Button>
      </div>
    </div>
  );
};

interface ComparisonCardProps {
  course: GolfCourse;
  isChampion: boolean;
  onSelect: () => void;
}

const ComparisonCard: React.FC<ComparisonCardProps> = ({
  course,
  isChampion,
  onSelect,
}) => {
  return (
    <Card className="overflow-hidden border-2 hover:border-primary transition-colors cursor-pointer group relative" onClick={onSelect}>
      <div className="h-48 sm:h-64 md:h-72">
        <ImageWithFallback
          src={course.imageUrl}
          alt={course.name}
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-300"
        />
        {course.rating && (
          <div className="absolute top-3 right-3">
            <CourseRatingBadge rating={course.rating} />
          </div>
        )}
        {isChampion && (
          <div className="absolute top-3 left-3 bg-primary text-primary-foreground rounded-full px-3 py-1 text-sm font-medium">
            Champion
          </div>
        )}
      </div>
      <div className="p-4 bg-card">
        <h3 className="text-primary text-lg">{course.name}</h3>
        <p className="text-secondary-foreground">{course.location}</p>
        
        {course.courseStyle && (
          <div className="mt-2">
            <span className="inline-flex items-center rounded-full border border-primary/20 px-2 py-0.5 text-xs font-medium text-primary mr-1">
              {course.courseStyle}
            </span>
            {course.par && (
              <span className="inline-flex items-center rounded-full border border-primary/20 px-2 py-0.5 text-xs font-medium text-primary">
                Par {course.par}
              </span>
            )}
          </div>
        )}
        
        <div className="mt-4 flex justify-center">
          <Button className="bg-primary text-primary-foreground w-full">
            I Prefer This Course
          </Button>
        </div>
      </div>
    </Card>
  );
};