import React from "react";
import { useGolfCourses } from "./GolfCourseContext";

interface NavigationProps {
  activeView: string;
  setActiveView: (view: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activeView, setActiveView }) => {
  const { getPlayedCoursesCount } = useGolfCourses();
  
  const hasRatedCourses = getPlayedCoursesCount() > 0;
  
  return (
    <div className="flex overflow-x-auto gap-2 bg-card/50 p-2 rounded-lg shadow-sm border border-primary/10">
      {(!hasRatedCourses || activeView === "initial") && (
        <button
          className={`px-4 py-2 rounded-md ${
            activeView === "initial"
              ? "bg-primary text-primary-foreground"
              : "hover:bg-secondary/20 text-secondary-foreground"
          } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
          onClick={() => setActiveView("initial")}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M11 17.5a6 6 0 1 0 0-12 6 6 0 0 0 0 12Z"></path>
            <path d="m15.2 13.5-1.2.5m-7.2 3-1.2.5"></path>
            <path d="m2 21 3.5-1.5m14-6L23 12M4.5 9.5 1 11"></path>
          </svg>
          Initial Ratings
        </button>
      )}

      <button
        className={`px-4 py-2 rounded-md ${
          activeView === "search"
            ? "bg-primary text-primary-foreground"
            : "hover:bg-secondary/20 text-secondary-foreground"
        } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
        onClick={() => setActiveView("search")}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="11" cy="11" r="8"></circle>
          <path d="m21 21-4.35-4.35"></path>
        </svg>
        Find Courses
      </button>
      
      <button
        className={`px-4 py-2 rounded-md ${
          activeView === "add"
            ? "bg-primary text-primary-foreground"
            : "hover:bg-secondary/20 text-secondary-foreground"
        } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
        onClick={() => setActiveView("add")}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 5v14"></path>
          <path d="M5 12h14"></path>
        </svg>
        Add Course
      </button>
      
      <button
        className={`px-4 py-2 rounded-md ${
          activeView === "compare"
            ? "bg-primary text-primary-foreground"
            : "hover:bg-secondary/20 text-secondary-foreground"
        } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
        onClick={() => setActiveView("compare")}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="8" height="18" x="4" y="3" rx="1"></rect>
          <rect width="8" height="18" x="12" y="3" rx="1"></rect>
        </svg>
        Compare
      </button>
      
      <button
        className={`px-4 py-2 rounded-md ${
          activeView === "rankings"
            ? "bg-primary text-primary-foreground"
            : "hover:bg-secondary/20 text-secondary-foreground"
        } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
        onClick={() => setActiveView("rankings")}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m9.5 7.5-2 2a20.5 20.5 0 0 0-2 4.5 8.7 8.7 0 0 1-2.5 4"></path>
          <path d="M7.5 13.5a16 16 0 0 0 2.5 3 6 6 0 0 0 8.5 0 16 16 0 0 0 2.5-3"></path>
          <path d="m14.5 7.5 2 2a20.5 20.5 0 0 1 2 4.5 8.7 8.7 0 0 0 2.5 4"></path>
          <path d="M9 4h6l1 2H8Z"></path>
        </svg>
        My Courses
      </button>
      
      <button
        className={`px-4 py-2 rounded-md ${
          activeView === "profile"
            ? "bg-primary text-primary-foreground"
            : "hover:bg-secondary/20 text-secondary-foreground"
        } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
        onClick={() => setActiveView("profile")}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="8" r="5"></circle>
          <path d="M20 21a8 8 0 1 0-16 0"></path>
        </svg>
        Profile
      </button>
      
      <button
        className={`px-4 py-2 rounded-md ${
          activeView === "bulk"
            ? "bg-primary text-primary-foreground"
            : "hover:bg-secondary/20 text-secondary-foreground"
        } flex items-center gap-1.5 whitespace-nowrap transition-colors`}
        onClick={() => setActiveView("bulk")}
      >
        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 0 1-2 2Zm14-10v5H10v-5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2Z"></path>
          <path d="M6 11V9a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2"></path>
          <path d="M4 5V3a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2"></path>
        </svg>
        Bulk Import
      </button>
    </div>
  );
};