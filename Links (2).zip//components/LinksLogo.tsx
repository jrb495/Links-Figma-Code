import React from 'react';

export const LinksLogo: React.FC<{ className?: string; showTagline?: boolean }> = ({ 
  className = "",
  showTagline = true
}) => {
  return (
    <div className={`relative ${className}`}>
      <div className="flex flex-col">
        {/* Main logo */}
        <svg 
          xmlns="http://www.w3.org/2000/svg" 
          viewBox="0 0 140 40" 
          fill="none" 
          className="w-full"
          aria-label="Links logo"
        >
          {/* Letter L */}
          <path 
            d="M15 8H8V32H26V26H15V8Z" 
            fill="currentColor" 
          />
          
          {/* Letter I */}
          <path 
            d="M32 8H25V32H32V8Z" 
            fill="currentColor" 
          />
          
          {/* Letter N */}
          <path 
            d="M52 8H45V32H52V17L63 32H70V8H63V23L52 8Z" 
            fill="currentColor" 
          />
          
          {/* Letter K */}
          <path 
            d="M85 8H78V32H85V23L96 32H105L92 20L104 8H95L85 18V8Z" 
            fill="currentColor" 
          />
          
          {/* Letter S */}
          <path 
            d="M126 19.5C130 19.5 132 17 132 13.5C132 10 128 8 122 8H110V32H123C129 32 132 29 132 25C132 21 128 19.5 126 19.5ZM117 14H122C124 14 125 14.5 125 15.5C125 16.5 124 17 122 17H117V14ZM122 26H117V22H122C124 22 125 22.5 125 24C125 25.5 124 26 122 26Z" 
            fill="currentColor" 
          />
          
          {/* Golf Flag */}
          <g className="golf-flag">
            <line 
              x1="110" 
              y1="4" 
              x2="110" 
              y2="13" 
              stroke="currentColor" 
              strokeWidth="1.5"
            />
            <path 
              d="M110 4L104 8.5L110 13" 
              fill="currentColor" 
              stroke="currentColor"
              strokeWidth="0.5"
              opacity="0.9"
            />
          </g>
          
          {/* Ball */}
          <circle 
            cx="122" 
            cy="11" 
            r="3" 
            fill="currentColor" 
            opacity="0.8"
            className="golf-ball"
          />
        </svg>
        
        {/* Tagline */}
        {showTagline && (
          <div className="mt-1 text-sm text-primary/80 font-medium tracking-wide">
            Your scorecard for courses
          </div>
        )}
      </div>
    </div>
  );
};