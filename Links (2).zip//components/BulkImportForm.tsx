import React, { useState, useRef, useCallback } from "react";
import { useGolfCourses } from "./GolfCourseContext";
import { CourseDatabase } from "./types";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Alert } from "./ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

export const BulkImportForm: React.FC = () => {
  const { importCourses, allCourses } = useGolfCourses();
  const [importData, setImportData] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<{
    success: boolean;
    message: string;
    count?: number;
  } | null>(null);
  const [activeTab, setActiveTab] = useState("paste");
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileContent, setFileContent] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetState = () => {
    setImportData("");
    setResult(null);
    setSelectedFile(null);
    setFileContent(null);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files[0]);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files[0]);
    }
  };

  const handleFiles = (file: File) => {
    if (!file.type.match('application/json') && !file.name.endsWith('.json')) {
      setResult({
        success: false,
        message: "The file must be a JSON file."
      });
      return;
    }

    setSelectedFile(file);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      setFileContent(content);
    };
    reader.readAsText(file);
  };

  const onButtonClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  const validateAndProcessData = useCallback((jsonContent: string) => {
    setIsProcessing(true);
    setResult(null);
    
    try {
      // Parse the JSON data
      let coursesToImport: CourseDatabase[];
      
      try {
        coursesToImport = JSON.parse(jsonContent.trim());
      } catch (error) {
        throw new Error("Invalid JSON format. Please check your data format.");
      }
      
      // Validate the data structure
      if (!Array.isArray(coursesToImport)) {
        throw new Error("Data must be an array of course objects.");
      }
      
      // Validate each course
      coursesToImport = coursesToImport.map((course, index) => {
        if (!course.name || !course.location) {
          throw new Error(`Course at index ${index} is missing required fields (name, location).`);
        }
        
        // Ensure the course has an ID
        return {
          ...course,
          id: course.id || `imported-${crypto.randomUUID()}`
        };
      });
      
      // Import the courses
      importCourses(coursesToImport);
      
      // Display success message
      setResult({
        success: true,
        message: `Successfully imported ${coursesToImport.length} new courses.`,
        count: coursesToImport.length
      });
      
      // Reset the form
      setImportData("");
      setSelectedFile(null);
      setFileContent(null);
    } catch (error) {
      // Display error message
      setResult({
        success: false,
        message: error instanceof Error ? error.message : "An unknown error occurred."
      });
    } finally {
      setIsProcessing(false);
    }
  }, [importCourses]);

  const handleImport = () => {
    if (activeTab === "paste") {
      validateAndProcessData(importData);
    } else if (activeTab === "upload" && fileContent) {
      validateAndProcessData(fileContent);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-primary mb-2">Bulk Import Courses</h2>
        <p className="text-secondary-foreground">
          Import multiple courses at once by providing a JSON array of course objects
        </p>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="paste">Paste JSON</TabsTrigger>
          <TabsTrigger value="upload">Upload File</TabsTrigger>
        </TabsList>
        
        <TabsContent value="paste" className="space-y-4">
          <div className="bg-card/50 p-6 rounded-lg border border-primary/10 shadow-sm space-y-4">
            <div>
              <label htmlFor="import-data" className="block mb-2">
                Paste your JSON data below:
              </label>
              <Textarea 
                id="import-data"
                value={importData}
                onChange={(e) => setImportData(e.target.value)}
                placeholder={`[
  {
    "name": "Example Golf Club",
    "location": "City, State",
    "imageUrl": "https://example.com/image.jpg",
    "description": "A beautiful course",
    "keywords": ["example", "keywords"]
  }
]`}
                rows={10}
                className="bg-background font-mono text-sm"
              />
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button 
                variant="outline" 
                onClick={resetState}
                className="border-primary/30 text-primary"
                disabled={isProcessing || !importData}
              >
                Reset
              </Button>
              <Button 
                onClick={handleImport}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
                disabled={isProcessing || !importData}
              >
                {isProcessing ? "Processing..." : "Import Courses"}
              </Button>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="upload" className="space-y-4">
          <div 
            className={`bg-card/50 p-6 rounded-lg border-2 border-dashed ${
              dragActive ? "border-primary" : "border-primary/30"
            } shadow-sm space-y-4 transition-colors`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="flex flex-col items-center justify-center py-8">
              <input
                ref={fileInputRef}
                type="file"
                accept=".json,application/json"
                onChange={handleFileInputChange}
                className="hidden"
              />
              
              {!selectedFile ? (
                <>
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="40" 
                    height="40" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    className="text-primary/60 mb-4"
                  >
                    <path d="M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242"></path>
                    <path d="M12 12v9"></path>
                    <path d="m16 16-4-4-4 4"></path>
                  </svg>
                  <h3 className="text-primary mb-1">Upload JSON File</h3>
                  <p className="text-secondary-foreground text-center mb-4">
                    Drag and drop your JSON file here, or click to browse
                  </p>
                  <Button 
                    variant="outline"
                    onClick={onButtonClick}
                    className="border-primary/30 text-primary"
                  >
                    Choose File
                  </Button>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2 mb-4">
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      width="24" 
                      height="24" 
                      viewBox="0 0 24 24" 
                      fill="none" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                      className="text-primary"
                    >
                      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
                      <polyline points="14 2 14 8 20 8"></polyline>
                      <path d="M8 13h2"></path>
                      <path d="M8 17h2"></path>
                      <path d="M14 13h2"></path>
                      <path d="M14 17h2"></path>
                    </svg>
                    <span className="text-primary font-medium">{selectedFile.name}</span>
                  </div>
                  
                  {fileContent && (
                    <div className="w-full mb-4">
                      <h4 className="text-sm font-medium text-secondary-foreground mb-1">File Preview:</h4>
                      <div className="bg-background p-3 rounded border border-input max-h-64 overflow-auto">
                        <pre className="text-xs font-mono whitespace-pre-wrap text-foreground/80">
                          {fileContent.length > 1000 
                            ? fileContent.substring(0, 1000) + "..." 
                            : fileContent}
                        </pre>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedFile(null);
                        setFileContent(null);
                      }}
                      className="border-primary/30 text-primary"
                    >
                      Remove
                    </Button>
                    <Button 
                      onClick={onButtonClick}
                      className="border-primary/30 text-primary"
                      variant="outline"
                    >
                      Choose Different File
                    </Button>
                  </div>
                </>
              )}
            </div>
            
            {selectedFile && (
              <div className="flex justify-end mt-4">
                <Button 
                  onClick={handleImport}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  disabled={isProcessing || !fileContent}
                >
                  {isProcessing ? "Processing..." : "Import Courses"}
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {result && (
        <Alert className={result.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
          <div className="flex items-center">
            {result.success ? (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500 mr-2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-red-500 mr-2">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
            )}
            <span className={result.success ? "text-green-800" : "text-red-800"}>
              {result.message}
            </span>
          </div>
          {result.success && result.count && result.count > 0 && (
            <p className="mt-2 text-green-700">
              You now have {allCourses.length} courses in your database.
            </p>
          )}
        </Alert>
      )}
      
      <div className="bg-secondary/20 p-4 rounded-lg border border-secondary/40">
        <h4 className="text-secondary-foreground mb-2">Import Format Requirements</h4>
        <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
          <li>Data must be a valid JSON array of course objects</li>
          <li>Each course must have at least a <code className="text-primary">name</code> and <code className="text-primary">location</code> field</li>
          <li>Optional fields: <code className="text-primary">id</code>, <code className="text-primary">imageUrl</code>, <code className="text-primary">description</code>, <code className="text-primary">keywords</code></li>
          <li>The <code className="text-primary">keywords</code> field should be an array of strings for improved searching</li>
        </ul>
        
        <div className="mt-4 pt-4 border-t border-secondary/30">
          <h4 className="text-secondary-foreground mb-2">Example Format</h4>
          <pre className="bg-background p-3 rounded border border-input text-xs font-mono whitespace-pre-wrap overflow-auto max-h-40">
{`[
  {
    "name": "Pine Valley Golf Club",
    "location": "Pine Valley, New Jersey",
    "imageUrl": "https://example.com/pinevalley.jpg",
    "description": "Consistently ranked as one of the top courses in the world",
    "courseStyle": "Parkland",
    "par": 70,
    "yearBuilt": 1918,
    "designer": "George Crump, H.S. Colt",
    "keywords": ["pine valley", "new jersey", "top ranked"]
  },
  {
    "name": "Merion Golf Club (East Course)",
    "location": "Ardmore, Pennsylvania",
    "imageUrl": "https://example.com/merion.jpg",
    "description": "Historic championship course",
    "courseStyle": "Parkland",
    "par": 70,
    "yearBuilt": 1912,
    "designer": "Hugh Wilson",
    "keywords": ["merion", "pennsylvania", "us open"]
  }
]`}
          </pre>
        </div>
      </div>
    </div>
  );
};