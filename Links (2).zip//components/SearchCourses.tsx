import React, { useState, useEffect, useRef } from "react";
import { useGolfCourses } from "./GolfCourseContext";
import { CourseDatabase } from "./types";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ScrollArea } from "./ui/scroll-area";

export const SearchCourses: React.FC = () => {
  const { 
    allCourses, 
    searchCourses, 
    getRecentSearches,
    addCourseFromDatabase, 
    setChampion,
    saveRecentSearch,
    getAllCourses
  } = useGolfCourses();
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<CourseDatabase[]>([]);
  const [suggestions, setSuggestions] = useState<CourseDatabase[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [searching, setSearching] = useState(false);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  
  // Load recent searches
  useEffect(() => {
    setRecentSearches(getRecentSearches());
  }, [getRecentSearches]);
  
  // Handle clicks outside suggestions dropdown
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
  
  // Generate suggestions as user types
  useEffect(() => {
    if (searchQuery.length > 0) {
      // Debounce suggestions
      const timer = setTimeout(() => {
        const results = searchCourses(searchQuery);
        // Sort results by relevance (exact name matches first)
        const sortedResults = [...results].sort((a, b) => {
          const aNameMatch = a.name.toLowerCase().includes(searchQuery.toLowerCase());
          const bNameMatch = b.name.toLowerCase().includes(searchQuery.toLowerCase());
          
          if (aNameMatch && !bNameMatch) return -1;
          if (!aNameMatch && bNameMatch) return 1;
          return 0;
        });
        
        setSuggestions(sortedResults.slice(0, 5)); // Limit to 5 suggestions
        setIsOpen(sortedResults.length > 0);
      }, 300);
      
      return () => clearTimeout(timer);
    } else {
      setSuggestions([]);
      setIsOpen(false);
    }
  }, [searchQuery, searchCourses]);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setSearching(true);
      // Save this search term
      saveRecentSearch(searchQuery);
      setRecentSearches(getRecentSearches());
      
      // Get results with more diversity
      const results = searchCourses(searchQuery, { diversify: true });
      setSearchResults(results);
      setHasSearched(true);
      setIsOpen(false);
      setSearching(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const handleSelectSuggestion = (course: CourseDatabase) => {
    setSearchQuery(course.name);
    setSearchResults([course]);
    setHasSearched(true);
    setIsOpen(false);
    saveRecentSearch(course.name);
    setRecentSearches(getRecentSearches());
  };

  const handleAddAndRank = (courseId: string) => {
    // Add the course to user's collection
    const courseResult = addCourseFromDatabase(courseId);
    
    // Navigate to the compare view and set this course as the champion
    if (courseResult) {
      setChampion(courseId);
      window.history.pushState({}, "", "/?view=compare");
      window.location.reload(); // Force reload to ensure view changes
    }
  };
  
  const handleRecentSearch = (term: string) => {
    setSearchQuery(term);
    handleSearch();
  };
  
  const renderNoResultsState = () => {
    return (
      <div className="p-8 rounded-lg bg-accent/30 shadow text-center border border-primary/20">
        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-primary/70 mb-2">
          <circle cx="11" cy="11" r="8"></circle>
          <path d="m21 21-4.35-4.35"></path>
          <path d="M8 11h6"></path>
        </svg>
        <h3 className="text-primary mb-1">No Courses Found</h3>
        <p className="text-secondary-foreground">
          Try a different search term or add a new course manually
        </p>
        <Button
          variant="outline"
          onClick={() => {
            setHasSearched(false);
            setSearchQuery("");
          }}
          className="mt-4 border-primary/30 text-primary"
        >
          Clear Search
        </Button>
      </div>
    );
  };

  // Get all available courses for the scrollable list
  const availableCourses = allCourses;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-primary mb-2">Find Courses</h2>
        <p className="text-secondary-foreground">
          Search our database for courses to add to your collection
        </p>
      </div>

      {/* Scrollable Course List */}
      <Card className="overflow-hidden border border-primary/20">
        <div className="p-3 border-b border-primary/10 bg-accent/20">
          <h3 className="text-primary">All Available Courses</h3>
        </div>
        <ScrollArea className="h-[180px]">
          <div className="p-3 grid gap-2">
            {availableCourses.map((course) => (
              <div
                key={course.id}
                className="flex items-center gap-3 hover:bg-accent/20 p-2 rounded cursor-pointer"
                onClick={() => handleSelectSuggestion(course)}
              >
                <div className="w-10 h-10 rounded-sm overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={course.imageUrl || "https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9?q=80&w=2070&auto=format&fit=crop"}
                    alt={course.name}
                    className="object-cover w-full h-full"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium truncate">{course.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{course.location}</div>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  className="flex-shrink-0 text-primary hover:bg-primary/10"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAddAndRank(course.id);
                  }}
                >
                  Rank
                </Button>
              </div>
            ))}
          </div>
        </ScrollArea>
      </Card>

      <div className="relative" ref={suggestionsRef}>
        <div className="flex gap-2">
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={handleKeyDown}
            onFocus={() => searchQuery && setSuggestions(searchCourses(searchQuery).slice(0, 5))}
            placeholder="Search by name or location..."
            className="bg-background"
          />
          <Button 
            onClick={handleSearch}
            disabled={searching}
            className="bg-primary hover:bg-primary/90 text-primary-foreground whitespace-nowrap"
          >
            {searching ? (
              <svg className="animate-spin h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.3-4.3"></path>
              </svg>
            )}
            Search
          </Button>
        </div>

        {/* Autocomplete suggestions */}
        {isOpen && suggestions.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-background rounded-md border border-input shadow-md">
            <ul className="py-1 max-h-60 overflow-auto">
              {suggestions.map((course) => (
                <li 
                  key={course.id} 
                  className="px-3 py-2 hover:bg-accent cursor-pointer flex items-center gap-3"
                  onClick={() => handleSelectSuggestion(course)}
                >
                  <div className="w-8 h-8 rounded-sm overflow-hidden flex-shrink-0">
                    <ImageWithFallback
                      src={course.imageUrl || "https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9?q=80&w=2070&auto=format&fit=crop"}
                      alt={course.name}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <div>
                    <div className="font-medium">{course.name}</div>
                    <div className="text-xs text-muted-foreground">{course.location}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
      
      {/* Recent searches */}
      {!hasSearched && recentSearches.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-secondary-foreground">Recent Searches</h3>
          <div className="flex flex-wrap gap-2">
            {recentSearches.map((term, index) => (
              <button
                key={index}
                onClick={() => handleRecentSearch(term)}
                className="bg-accent/40 hover:bg-accent/60 text-secondary-foreground text-sm rounded-full px-3 py-1 transition-colors"
              >
                {term}
              </button>
            ))}
          </div>
        </div>
      )}

      {hasSearched && searchResults.length === 0 ? (
        renderNoResultsState()
      ) : hasSearched ? (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-primary">{searchResults.length} Results</h3>
            <Button 
              variant="outline" 
              onClick={() => { 
                setHasSearched(false); 
                setSearchQuery("");
              }}
              size="sm"
              className="border-primary/30 text-primary hover:bg-primary/10"
            >
              Clear
            </Button>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            {searchResults.map((course) => (
              <CourseSearchResult 
                key={course.id} 
                course={course}
                onRank={() => handleAddAndRank(course.id)}
              />
            ))}
          </div>
        </div>
      ) : (
        <div className="p-8 rounded-lg bg-accent/30 shadow text-center border border-primary/20">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="mx-auto text-primary/70 mb-2">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <h3 className="text-primary mb-1">Search for Courses</h3>
          <p className="text-secondary-foreground">
            Enter a course name or location to search our database
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            Try searching for "Augusta", "California", or "Links" to see results
          </p>
        </div>
      )}
      
      <div className="mt-6 bg-secondary/20 p-4 rounded-lg border border-secondary/40">
        <h4 className="text-secondary-foreground mb-2">Can't find a course?</h4>
        <p className="text-muted-foreground mb-3">
          If you can't find the course you're looking for, you can always add it manually.
        </p>
        <Button 
          variant="outline" 
          className="border-primary text-primary hover:bg-primary/10"
          onClick={() => window.history.pushState({}, "", "/?view=add")}
        >
          Add Course Manually
        </Button>
      </div>
    </div>
  );
};

interface CourseSearchResultProps {
  course: CourseDatabase;
  onRank: () => void;
}

const CourseSearchResult: React.FC<CourseSearchResultProps> = ({ course, onRank }) => {
  return (
    <Card className="overflow-hidden border border-secondary/30 hover:border-primary/30 transition-colors bg-card flex flex-col">
      <div className="h-32">
        <ImageWithFallback
          src={course.imageUrl || "https://images.unsplash.com/photo-1587174186999-bd11ee0c51a9?q=80&w=2070&auto=format&fit=crop"}
          alt={course.name}
          className="object-cover w-full h-full"
        />
      </div>
      <div className="p-3 flex-1 flex flex-col">
        <h3 className="text-primary">{course.name}</h3>
        <p className="text-secondary-foreground text-sm">{course.location}</p>
        {course.description && (
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{course.description}</p>
        )}
        <div className="mt-auto pt-3">
          <Button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              onRank();
            }}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"></path>
              <line x1="4" x2="4" y1="22" y2="15"></line>
            </svg>
            Rank This Course
          </Button>
        </div>
      </div>
    </Card>
  );
};